package lab1;

public enum ClockType {
	LOGICAL, VECTOR
}
