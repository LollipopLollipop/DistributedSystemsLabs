package lab3;

public enum ClockType {
	LOGICAL, VECTOR
}
