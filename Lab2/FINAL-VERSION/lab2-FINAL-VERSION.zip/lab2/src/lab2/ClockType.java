package lab2;

public enum ClockType {
	LOGICAL, VECTOR
}
