package lab0;
import java.util.*;
import java.util.concurrent.*;
import java.io.File;
import javax.sound.midi.Receiver;

public class Checkfile extends Thread
{
	private final String conf_filename;
	private final String local_name;
	private final MessagePasser mp;
	private BackgroundSpeaker send;
	private BackgroundListener recv;
	private ConcurrentLinkedQueue<BackgroundStreamListener> wq;

	public Checkfile(String conf_filename, String local_name, MessagePasser mp, BackgroundSpeaker send, BackgroundListener recv, ConcurrentLinkedQueue<BackgroundStreamListener> wq)
	{
		this.conf_filename = conf_filename;
		this.local_name = local_name;
		this.mp = mp;
		this.send = send;
		this.recv = recv;
		this.wq = wq;
		this.setDaemon(true);
	}

	public void run()
	{
		File ff = new File(conf_filename);
		long last_modify = ff.lastModified();
		while(true)
		{
			long temp = ff.lastModified();
			if(temp != last_modify)
			{
				System.out.println("File changed");
				last_modify = temp;
				/* shutdown Sender thread, there's no need to kill Receiver thread, because receiver 
				   thread binds to the machine IP address of the running program. It doesn't make sense when
				   one could modify his own IP address without exitting the current running program.
				 */
				send.interrupt();
				recv.interrupt();
				
				ConcurrentLinkedQueue<BackgroundStreamListener> worker_queue = wq;
				/* shutdown all the ReceiverWorker threads */
				synchronized(wq)
				{
					while(!worker_queue.isEmpty())
					{
						BackgroundStreamListener temp_rw = (BackgroundStreamListener)worker_queue.poll();
						//temp_rw.setFlag();
						temp_rw.interrupt();
					}
				}
//				wq.setLab0Flag();
/*				try
				{
					Thread.sleep(500);
				}
				catch(InterruptedException iex)
				{
					iex.printStackTrace();
				}
*/
				/* restart initing MessagePasser, Sender and Receiver threads */
				mp.init();
				send = new BackgroundSpeaker(mp);
				send.start();
				recv = new BackgroundListener(mp,local_name,wq);
			}
			else
			{
				Thread.yield();
			}
		}
	}
}
