package lab0;

public class Rule {
	private String action;
	private String src = null;
	private String dest = null;
	private String kind = null;
	private int seq_num = -1;
	private String duplicate = null;
	public Rule(String action)
	{
		this.action = action;
	}
	public void setAction(String action){this.action = action;}
	public void setSrc(String src){this.src = src;}
	public void setDest(String dest){this.dest = dest;}
	public void setKind(String kind){this.kind = kind;}
	public void setSeqNum(int seq_num){this.seq_num = seq_num;}
	public void setDuplicate(String duplicate){this.duplicate = duplicate;}
	
	public String getAction(){return action;}
	public String getSrc(){return src;}
	public String getDest(){return dest;}
	public String getKind(){return kind;}
	public int getSeqNum(){return seq_num;}
	public String getDuplicate(){return duplicate;}

}