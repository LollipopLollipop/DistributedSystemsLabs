package lab0;

import java.io.*;
import java.net.ConnectException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.LinkedBlockingQueue;

import org.yaml.snakeyaml.*;

public class MessagePasser {
	private final String conf_filename;
	private final String local_name;
	private int message_id;
	private HashMap<String, User> users = new HashMap<String, User>();
	private ArrayList<Rule> send_rules = new ArrayList<Rule>();
	private ArrayList<Rule> receive_rules = new ArrayList<Rule>();
	public BlockingQueue<Message> send_queue = new LinkedBlockingQueue<Message>();
	private Queue<Message> send_delay_queue = new LinkedList<Message>();
	public Queue<Message> receive_queue = new LinkedList<Message>();
	public Queue<Message> delay_receive_queue = new LinkedList<Message>();
	private ConcurrentLinkedQueue<BackgroundStreamListener> socket_queue = new ConcurrentLinkedQueue<BackgroundStreamListener>();
	
	ObjectInputStream in;
	private HashMap<String, ObjectOutputStream> existed_sockets = new HashMap<String, ObjectOutputStream>();
	public MessagePasser(String configuration_filename, String local_name) {
		this.conf_filename = configuration_filename;
		this.local_name = local_name;
	}
	public void init()
	{
		
		this.message_id = 0;
		//send_queue.clear();
		//receive_queue.clear();
		//delay_send_queue.clear();
		//delay_receive_queue.clear();
		users.clear();
		send_rules.clear();
		receive_rules.clear();
		send_delay_queue.clear();
		//cached_output_streams.clear();

		parse_config();
		/*
		try{
			System.out.print(users.get(local_name).getPort());
			ServerSocket serverSocket = new ServerSocket(users.get(local_name).getPort());
			Socket clientSocket = serverSocket.accept();
			in = new ObjectInputStream(clientSocket.getInputStream());
			
		}
		catch(ConnectException cex)
		{
			cex.printStackTrace();
		}
		catch(SocketException sex)
		{
			sex.printStackTrace();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		*/
		 
	}
	public void parse_config()
	{
		FileInputStream fis = null;
		try
		{
			fis = new FileInputStream(conf_filename);
			Yaml yaml = new Yaml();
			
			Map<String, Object> data = (Map<String, Object>)yaml.load(fis);
			ArrayList<HashMap<String, Object> > config = (ArrayList<HashMap<String, Object> >)data.get("configuration");
			for(HashMap<String, Object> node : config)
			{
				String Name = (String)node.get("name");
				User user = new User(Name, (String)node.get("ip"), (Integer)node.get("port"));
				users.put(Name, user);
			}
			if(!users.containsKey(local_name))
			{
				System.err.println(local_name + " is illegal, what happend?");
				System.exit(1);
			}
			
			ArrayList<HashMap<String, Object> > orig_send_rules = (ArrayList<HashMap<String, Object> >)data.get("sendRules");
			for(HashMap<String, Object> s_rule : orig_send_rules)
			{
				String action = (String)s_rule.get("action");
				Rule rule = new Rule(action);
				for(String key: s_rule.keySet())
				{
					if(key.equals("src"))
						rule.setSrc((String)s_rule.get(key));
					if(key.equals("dest"))
						rule.setDest((String)s_rule.get(key));
					if(key.equals("kind"))
						rule.setKind((String)s_rule.get(key));
					if(key.equals("seqNum"))
						rule.setSeqNum((Integer)s_rule.get(key));
					//if(key.equals("Nth"))
						//r.setNth((Integer)s_rule.get(key));
					//if(key.equals("EveryNth"))
						//r.setEveryNth((Integer)s_rule.get(key));
				}
				send_rules.add(rule);
			}

			ArrayList<HashMap<String, Object> > orig_receive_rules = (ArrayList<HashMap<String, Object> >)data.get("receiveRules");
			for(HashMap<String, Object> r_rule : orig_receive_rules)
			{
				String action = (String)r_rule.get("action");
				Rule rule = new Rule(action);
				for(String key: r_rule.keySet())
				{
					if(key.equals("src"))
						rule.setSrc((String)r_rule.get(key));
					if(key.equals("dest"))
						rule.setDest((String)r_rule.get(key));
					if(key.equals("kind"))
						rule.setKind((String)r_rule.get(key));
					if(key.equals("seqNum"))
						rule.setSeqNum((Integer)r_rule.get(key));
					//if(key.equals("Nth"))
						//r.setNth((Integer)r_rule.get(key));
					//if(key.equals("EveryNth"))
						//r.setEveryNth((Integer)r_rule.get(key));
				}
				receive_rules.add(rule);
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			try
			{
				if(fis != null)
					fis.close();
			}
			catch(IOException ioe)
			{
				ioe.printStackTrace();
			}
		}
	}
	public HashMap<String, User> getUsers(){return users;}
	public BlockingQueue<Message> getSendQueue(){return send_queue;}
	public void send(Message message) {
		message.set_seqNum(++message_id);
		Rule rule = send_rule_processing(message);		
		if(rule == null){//No rule matches 
			// To be continued send;
			//setViaSocket(message);
			send_queue.add(message);
			while(!send_delay_queue.isEmpty()){
				//setViaSocket(send_delay_queue.poll());
				send_queue.add(send_delay_queue.poll());
			}
		}
		else{
			//System.out.println(rule.getAction());
			if(rule.getAction().equals("drop")){
				return; // irgnore this message
			}
			else if(rule.getAction().equals("delay")){
				send_delay_queue.add(message);
				return;
			}
			//setViaSocket(message);
			send_queue.add(message);
			if(rule.getAction().equals("duplicate")){
				//System.out.println("duplicate");
				Message message_copy = message.copy();
				message_copy.set_seqNum(++message_id);
				//setViaSocket(message_copy);
				send_queue.add(message_copy);
			}
			while(!send_delay_queue.isEmpty()){
				//setViaSocket(send_delay_queue.poll());
				send_queue.add(send_delay_queue.poll());
			}
		}
	}
	/*
	public void setViaSocket(Message message){
		System.out.print("message_to_be_sent:"+message.get_data());
		if (message == null)
			return;
		User dst_usr = users.get(message.get_dest());
		try{
			System.out.println(dst_usr.getIp());
			System.out.println(dst_usr.getPort());
			ObjectOutputStream out = null;
			if(existed_sockets.containsKey(dst_usr.getName())){
				out = existed_sockets.get(dst_usr.getName());
				
			}
			else{
				Socket kkSocket = new Socket(dst_usr.getIp(), dst_usr.getPort());
				out = new ObjectOutputStream(kkSocket.getOutputStream());
				existed_sockets.put(dst_usr.getName(), out);
			}
			out.writeObject(message);
			out.flush();
		}
		catch(ConnectException cex)
		{
			cex.printStackTrace();
		}
		catch(SocketException sex)
		{
			sex.printStackTrace();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}

	}*/
	
	public Message receive() {
		if(receive_queue.isEmpty())
			return null;
		return receive_queue.poll();
	} // may block. Doesn't have to.
	
	public Rule send_rule_processing(Message message)
	{
		for(Rule rule: send_rules)
		{
			if(rule.getSrc() != null && !rule.getSrc().equals(message.get_source()))
				continue;
			if(rule.getDest() != null && !rule.getDest().equals(message.get_dest()))
				continue;
			else if(rule.getKind() != null && !rule.getKind().equals(message.get_kind()))
				continue;
			else if(rule.getSeqNum() > 0 && rule.getSeqNum() != message.get_seqNum())
				continue;

			return rule;  //Matched
		}
		return null;// No rule matched
	}
	public Rule receive_rule_processing(Message message)
	{
		for(Rule rule: receive_rules)
		{
			if(rule.getSrc() != null && !rule.getSrc().equals(message.get_source()))
				continue;
			if(rule.getDest() != null && !rule.getDest().equals(message.get_dest()))
				continue;
			else if(rule.getKind() != null && !rule.getKind().equals(message.get_kind()))
				continue;
			else if(rule.getSeqNum() > 0 && rule.getSeqNum() != message.get_seqNum())
				continue;
			else if(rule.getDuplicate() != null && !rule.getDuplicate().equals(message.get_duplicate()))
				continue;
			return rule;  //Matched
		}
		return null;// No rule matched
	}
	public ConcurrentLinkedQueue<BackgroundStreamListener> get_all_sockets(){
		return socket_queue;
	}
}