package lab0;
import java.io.Serializable;

public class Message implements Serializable {
	private int seqNum;
	private String src;
	private String dest;
	private String kind;
	private Object data;
	private boolean dupe;
	
	public Message(String src, String dest, String kind, Object data){
		this.src = src;
		this.dest = dest;
		this.kind = kind;
		this.data = data;
		this.seqNum = -1; // -1 represents not used message
		this.dupe = false;
	}
	
	// These settors are used by MessagePasser.send, not your app
	
	//Interfaces - set value
	public void set_source(String source){
		this.src = source;
	}
	public void set_dest(String dest){
		this.dest = dest;
	}
	public void set_kind(String kind){
		this.kind = kind;
	}
	public void set_data(String data){
		this.data = data;
	}	
	public void set_seqNum(int sequenceNumber){
		this.seqNum = sequenceNumber;
	}
	public void set_duplicate(Boolean dupe){
		this.dupe = dupe;
	}
	
	//Interfaces - get values
	public String get_source(){
		return this.src;
	}
	public String get_dest(){
		return this.dest;
	}
	public String get_kind(){
		return this.kind;
	}
	public Object get_data(){
		return this.data;
	}	
	public int get_seqNum(){
		return this.seqNum;
	}
	public boolean get_duplicate(){
		return this.dupe;
	}
	
	//toString
	public String toString()
	{
		return ("id:" + this.seqNum + ",source:" + this.src + ",destination:" + this.dest + ",kind:" + this.kind + ",data:" + this.data + ",duplication" + ((this.dupe==true)?"Yes":"No"));
	}
	
	//Copy
	public Message copy(){
		Message new_message = new Message(this.src,this.dest,this.kind,this.data);
		return new_message;	
	}

}