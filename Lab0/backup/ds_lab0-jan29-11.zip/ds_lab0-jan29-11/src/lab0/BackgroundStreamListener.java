package lab0;

import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.util.concurrent.ConcurrentLinkedQueue;

public class BackgroundStreamListener extends Thread{
	private Socket socket;
	private MessagePasser mp;
	//private ConcurrentLinkedQueue worker_queue;
	//private boolean flag = true;
	private ConcurrentLinkedQueue<BackgroundStreamListener> sq;
	public BackgroundStreamListener(Socket conn_sock, MessagePasser mp, ConcurrentLinkedQueue<BackgroundStreamListener> sq) {
		// TODO Auto-generated constructor stub
		this.socket = conn_sock;
		this.mp = mp;
		this.sq = sq;
	}
	
	public void run()
	{
		ObjectInputStream in = null;
		try{
			in = new ObjectInputStream(socket.getInputStream());
			while(true){
				Message message = (Message)in.readObject();
				Rule rule = mp.receive_rule_processing(message);		
				if(rule == null){//No rule matches 
					mp.receive_queue.add(message);
					while(!mp.delay_receive_queue.isEmpty()){
						mp.receive_queue.add(mp.delay_receive_queue.poll());
					}
				}
				else{
					System.out.println(rule.getAction());
					if(rule.getAction().equals("drop")){
						return; // irgnore this message
					}
					else if(rule.getAction().equals("delay")){
						mp.delay_receive_queue.add(message);
						return;
					}
					mp.receive_queue.add(message);
					if(rule.getAction().equals("duplicate")){
						System.out.println("duplicate");
						Message message_copy = message.copy();
						//message_copy.set_seqNum(++message_id);
						mp.receive_queue.add(message_copy);
					}
					while(!mp.delay_receive_queue.isEmpty()){
						mp.receive_queue.add(mp.delay_receive_queue.poll());
					}
				}
			}
		}
		catch(ClassNotFoundException cnfe)
		{
			cnfe.printStackTrace();
		}
		catch(EOFException eof)
		{
			eof.printStackTrace();
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			try
			{
				if(in != null)
					in.close();
			}
			catch(IOException ioe)
			{
				ioe.printStackTrace();
			}
			sq.remove(this); // since this thread will end, remove it from worker thread list;
		}
	}
}
