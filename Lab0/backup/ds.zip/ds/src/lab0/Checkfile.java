package lab0;

import java.util.concurrent.*;
import java.io.File;
import java.io.IOException;
import java.net.Socket;

/*
 * This is a thread to check whether the configuration file has been changed or not.
 * If changed, stop current jobs(threads), initialize again with new configuration and restart.
 */
public class Checkfile extends Thread
{
	private String conf_filename;
	private String local_name;
	private MessagePasser mp;
	private BackgroundSpeaker speaker;
	private BackgroundListener receiver;
	private ConcurrentLinkedQueue<BackgroundStreamListener> streamlistener;

	
	public Checkfile(String conf_filename, String local_name, MessagePasser mp, BackgroundSpeaker speaker, BackgroundListener receiver, ConcurrentLinkedQueue<BackgroundStreamListener> streamlistener)
	{
		this.conf_filename = conf_filename;
		this.local_name = local_name;
		this.mp = mp;
		this.speaker = speaker;
		this.receiver = receiver;
		this.streamlistener = streamlistener;
		this.setDaemon(true);
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Thread#run()
	 */
	public void run()
	{
		File ff = new File(conf_filename);
		long last_modify = ff.lastModified();
		while(true)
		{
			long temp = ff.lastModified();
			if(temp != last_modify)
			{
				
				System.out.println("Note: Configuration file has been changed.");
				last_modify = temp;
				//Close current speaker threads by sending interrupt signals
				//
				speaker.interrupt();
				receiver.close_socket(true);
				receiver.interrupt();;
				//Empty Streamlistener queue. 
				ConcurrentLinkedQueue<BackgroundStreamListener> cur_streamlistener = streamlistener;
				System.out.println("size:"+cur_streamlistener.size());
				synchronized(cur_streamlistener)
				{
					while(!cur_streamlistener.isEmpty())
					{//Close all current sockets.
						System.out.println("sockets exsist");
						BackgroundStreamListener templistener = cur_streamlistener.poll();
						try {
							templistener.get_socket().close();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						templistener.interrupt();
					}
				}
				
				//Initialize messagepasser with new configuration file
				mp.setup();
				//restart new threads of speaker and receiver
				speaker = new BackgroundSpeaker(mp);
				speaker.start();
				receiver = new BackgroundListener(mp,local_name,streamlistener);
				System.out.println("new receiver");
				//receiver.start();
			}
			else
			{
				//Keep alive and inform CPU its state
				Thread.yield();
			}
		}
	}
}
