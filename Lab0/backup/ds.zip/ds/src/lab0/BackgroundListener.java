package lab0;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.ConnectException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.concurrent.ConcurrentLinkedQueue;

public class BackgroundListener extends Thread{
	private MessagePasser mp;
	private String local_name;
	private ConcurrentLinkedQueue<BackgroundStreamListener> sq;
	public BackgroundListener(MessagePasser mp, String local_name, ConcurrentLinkedQueue<BackgroundStreamListener> sq) {
		// TODO Auto-generated constructor stub
		this.mp = mp;
		this.local_name = local_name;
		this.sq = sq;
	}
	private ServerSocket serverSocket = null;
	public void close_socket(boolean flag){
		try {
			System.out.println("server close");
			if(this.serverSocket.isClosed()){
				System.out.print("no");
				return;
			}
			else{
				System.out.println("has");
				this.serverSocket.close();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.print("Wrong");
		}
	}
	
	public void run()
	{
		
		Node user = mp.get_all_nodes().get(local_name);
		//Message msg = null;
		serverSocket = null;
		try
		{
			serverSocket = new ServerSocket(user.get_port());
			while(true)
			{
				//System.out.print("Wait accept");
				Socket clientSocket = serverSocket.accept();
				//System.out.print("Accepted already");
				/*ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream());
				Message message = (Message)in.readObject();
				Rule rule = mp.receive_rule_processing(message);		
				if(rule == null){//No rule matches 
					mp.receive_queue.add(message);
					while(!mp.delay_receive_queue.isEmpty()){
						mp.receive_queue.add(mp.delay_receive_queue.poll());
					}
				}
				else{
					System.out.println(rule.getAction());
					if(rule.getAction().equals("drop")){
						return; // irgnore this message
					}
					else if(rule.getAction().equals("delay")){
						mp.delay_receive_queue.add(message);
						return;
					}
					mp.receive_queue.add(message);
					if(rule.getAction().equals("duplicate")){
						System.out.println("duplicate");
						Message message_copy = message.copy();
						//message_copy.set_seqNum(++message_id);
						mp.receive_queue.add(message_copy);
					}
					while(!mp.delay_receive_queue.isEmpty()){
						mp.receive_queue.add(mp.delay_receive_queue.poll());
					}
				}*/
				BackgroundStreamListener bgStreamLis = new BackgroundStreamListener(clientSocket, mp, sq);
				sq.add(bgStreamLis);
				bgStreamLis.start();
			}
		}
		catch(ConnectException cex)
		{
			//cex.printStackTrace();
		}
		catch(SocketException sex)
		{
			System.out.println("SocketException!!!");
			//sex.printStackTrace();
		}
		catch(IOException ioe)
		{
			//ioe.printStackTrace();
		}
		catch(Exception ex)
		{
			//ex.printStackTrace();
		}
		/*try {
			serverSocket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		serverSocket = null;
	}
}
