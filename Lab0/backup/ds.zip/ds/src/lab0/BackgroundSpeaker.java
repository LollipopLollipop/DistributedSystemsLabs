package lab0;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.ConnectException;
import java.net.Socket;
import java.net.SocketException;
import java.util.HashMap;
import java.util.Queue;
import java.util.concurrent.BlockingQueue;

public class BackgroundSpeaker extends Thread{
	private MessagePasser mp;
	public BackgroundSpeaker(MessagePasser mp) {
		// TODO Auto-generated constructor stub
		this.mp = mp;
	}
	public void run()
	{
		Message mm = null;
		Node uu = null;
		Socket ss = null;
		ObjectOutputStream out = null;
		BlockingQueue<Message> bq = mp.get_send_queue();
		HashMap<String, ObjectOutputStream> existed_sockets = new HashMap<String, ObjectOutputStream>();
		while(true)
		{
			try
			{
				mm = bq.take(); // throw interrupt error if the thread is interrupted when it is on the thread
				uu = mp.get_all_nodes().get(mm.get_dest()); //send message to that user
			}
			catch(InterruptedException inex)
			{
				//interrupted by file changed, exit the thread
				break;
			}
			
			try
			{
				if(existed_sockets.containsKey(uu.get_name())){
					out = existed_sockets.get(uu.get_name());		
				}
				else{
					ss = new Socket(uu.get_ip(), uu.get_port());
					out = new ObjectOutputStream(ss.getOutputStream());
					existed_sockets.put(uu.get_name(), out);
				}
				out.writeObject(mm);
				out.flush();
			}
			catch(ConnectException cex)
			{
				System.out.println("Cannot connect to the client, " + mm.get_dest());
				try
				{
					if(ss != null)
						ss.close();
				}
				catch(IOException ioe)
				{
					ioe.printStackTrace();
				}
			}
			catch(SocketException sex)
			{
				//sex.printStackTrace();
				ObjectOutputStream temp_out = existed_sockets.remove(uu.get_name());
				try{
					if(temp_out != null)
						temp_out.close();
				}
				catch(IOException ioe)
				{
					; // remote receiver offline, temp_oos.close() error, do nothing
					//ioe.printStackTrace();
				}
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
		}
		return;
	}

}
